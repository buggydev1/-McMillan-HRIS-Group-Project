package com.TreVyon_Bates.ClockInOrOut;
import java.util.Scanner;

public class ClockInOrOut
{
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args)
    {
        String clockStatus = "";
        int clockInput = 0;
        while(clockInput != 1 && clockInput != 2)
        {
            System.out.println("Type 1 to clock in or 2 to clock out.");
            clockInput = scanner.nextInt();
            if (clockInput == 1 && !clockStatus.equals("Clocked In"))
            {
                clockStatus = "Clocked In";
                System.out.println(clockStatus);
            }
            else if(clockStatus.equals("Clocked In"))
            {
                System.out.println("You're already clocked in.");
            }

            if(clockInput == 2 && !clockStatus.equals("Clocked Out"))
            {
                clockStatus = "Clocked Out";
                System.out.println(clockStatus);
            }
            else if(clockStatus.equals("Clocked Out"))
            {
                System.out.println("You're already clocked out.");
            }
        }
    }
}
