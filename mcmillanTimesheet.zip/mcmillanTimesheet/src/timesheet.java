  /* 40 hour work week for an employee, if
   * exceeded, it is OT so hours after 40 * 1.5
   * inputting employee id, name and total number of
   * hours worked in a week then outputs a weekly
   * timesheet report
   * author @merkys
   */

  import javax.swing.*;
  import java.awt.*;
  import java.text.DecimalFormat;
  import java.util.Scanner;

  public class timesheet
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        JTextArea myArea = new JTextArea(20,20);
        DecimalFormat f =  new DecimalFormat("$0,000.00");

        //variable declarations
        final int STANDARD_HOURS_WORK = 40;                             //40 hours a work week
        String employeeID;
        String employeeName;
        double hoursWorked;
        double hourlyRate;
        double pay;
        double overtime = 0;
        double overtimeRate = 0;
        double overtimePay = 0;
        double grossPay;

        /* input statements for employee info and hours worked + hourly rate */
        System.out.println("Enter an employee ID: ");
        employeeID = keyboard.nextLine();

        System.out.println("Enter an employee name: ");
        employeeName = keyboard.nextLine();

        System.out.println("Enter # of hours worked: ");
        hoursWorked = keyboard.nextDouble();

        System.out.println("Enter your hourly rate: ");
        hourlyRate = keyboard.nextDouble();

        //if statement to calculate the pay with the info of # of hours if < 40 hours worked
        if(hoursWorked <= STANDARD_HOURS_WORK)
        {
            pay = hoursWorked * hourlyRate;
            grossPay = pay;
        }

        else           //overtime pay if > 40 hours worked
        {
            pay = STANDARD_HOURS_WORK * hourlyRate;
            overtime = hoursWorked - STANDARD_HOURS_WORK;
            overtimeRate = hourlyRate * 1.5;
            overtimePay = overtimeRate * overtime;
            grossPay = pay + overtimePay;
        }

        //printing weekly timesheet/payslip
        myArea.setEditable(false);                                      //set editable method = false
        myArea.setFont(new Font("Arial", Font.BOLD, 20));
        myArea.setText(
                "\tMCMILLAN & ASSOCIATES\n\t\t  TIMESHEET\n\n=========================" +
                "\nEmployeeID:\t\t" + employeeID +
                "\nEmployeeName:\t" + employeeName +
                "\nHoursWorked:\t" + hoursWorked +
                "\nHourlyRate:\t\t" + hourlyRate +
                "\nOvertime:\t\t" + overtime +
                "\nOTRate:\t\t" + overtimeRate +
                "\nOTPay:\t\t" + f.format(overtimePay) +
                "\nPay:\t\t" + f.format(pay) +
                "\n\nGross Pay:\t\t" + f.format(grossPay));
        
        JOptionPane.showMessageDialog(
                null, myArea, "McMillan Timesheet", JOptionPane.PLAIN_MESSAGE);

        //Print Payroll Report
        System.out.println();
        System.out.printf("%45s\n","McMillan Associates");                                       //(string format(45s = right aligned), "string") s=string (lowercase) , S= String (uppercase)
        System.out.printf("%50s\n\n","WEEKLY PAYROLL REPORT");                           //(String format(50s), "String"
        System.out.printf("%-8s%-20s%-8s%-6s%-6s%-8s%-11s%-11s%-11s\n",                 //displaying columns: -8s = left aligned etc)
                "EmpID","EmpName","HWorked","HRate","OT","OTRate","OTPay","BasicPay",
                "GrossSalary");
        System.out.printf(
                "%-8S%-12S%-8.2f%-6.2f%-6.2f%-8.2f$%,-11.2f$%,-11.2f$%-,11.2f",          //-8S = output would be uppercase w 8 characters, 8.1f% (hoursWorked) = - left aligned, 8 = 8 spaces, .1 = number of decimals, f = double
                employeeID,employeeName,hoursWorked,hourlyRate,overtime,overtimeRate,
                overtimePay,pay,grossPay);
    }
}
